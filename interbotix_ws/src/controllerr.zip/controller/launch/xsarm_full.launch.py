from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    SetEnvironmentVariable,
    OpaqueFunction,
    ExecuteProcess,
    IncludeLaunchDescription
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
import os


def get_omni_launch_include():
    """Helper function to create omni.launch.py include description"""
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                os.path.dirname(__file__),
                "omni.launch.py"
            )
        )
    )


def launch_setup(context, *args, **kwargs):
    # Resolve launch arguments
    use_sim = LaunchConfiguration('use_sim').perform(context)
    haptic_feedback = LaunchConfiguration('haptic_feedback').perform(context)
    teleoperation = LaunchConfiguration('teleoperation').perform(context)
    teleop_mode = LaunchConfiguration('teleop_mode').perform(context)
    
    nodes_to_launch = []
    
    # -------------------------
    # Teleoperation Setup
    # -------------------------
    if teleoperation.lower() == 'true':
        if teleop_mode.lower() == 'router':
            # Launch Zenoh daemon (router mode)
            zenoh = ExecuteProcess(
                cmd=['zenohd', '-l', 'tcp/0.0.0.0:7447'],
                output='screen'
            )
            nodes_to_launch.append(zenoh)
            print("[INFO] Teleoperation enabled → Launching Zenoh daemon (router mode)")
        elif teleop_mode.lower() == 'host':
            print("[INFO] Teleoperation enabled → omni.launch.py will be included (host mode)")
        else:
            print(f"[WARN] Invalid teleop_mode '{teleop_mode}'. Must be 'router' or 'host'")
    else:
        print("[INFO] Teleoperation disabled")
    
    # -------------------------
    # Simulation vs Real Robot
    # -------------------------
    if use_sim.lower() == 'true':
        # Simulation mode
        print("[INFO] Launching in SIMULATION mode")
        
        # Launch Gazebo simulation
        xsarm_sim = ExecuteProcess(
            cmd=[
                'ros2', 'launch', 'interbotix_xsarm_sim', 'xsarm_gz_classic.launch.py',
                'robot_model:=rx200'
            ],
            output='screen'
        )
        nodes_to_launch.append(xsarm_sim)
        
        # Launch arm control for simulation
        arm_control = ExecuteProcess(
            cmd=['ros2', 'run', 'controller', 'arm_control_sim'],
            output='screen'
        )
        nodes_to_launch.append(arm_control)
        
        # Launch effort controller
        effort_ctrl = ExecuteProcess(
            cmd=['ros2', 'run', 'controller', 'effort_controller'],
            output='screen'
        )
        nodes_to_launch.append(effort_ctrl)
        
    else:
        # Real robot mode
        print("[INFO] Launching in REAL ROBOT mode")
        
        # Launch real robot control
        xsarm_real = ExecuteProcess(
            cmd=[
                'ros2', 'launch', 'interbotix_xsarm_control', 'xsarm_control.launch.py',
                'robot_model:=rx200'
            ],
            output='screen'
        )
        nodes_to_launch.append(xsarm_real)
        
        # Launch arm control for real robot
        arm_control_real = ExecuteProcess(
            cmd=['ros2', 'run', 'controller', 'arm_control'],
            output='screen'
        )
        nodes_to_launch.append(arm_control_real)
    
    # -------------------------
    # Launch omni.launch.py (always included via IncludeLaunchDescription)
    # -------------------------
    omni_launch_common = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('omni_common'),
                'launch',
                'omni.launch.py'
            ])
        ])
    )
    nodes_to_launch.append(omni_launch_common)
    print("[INFO] Including omni.launch.py")
    
    # -------------------------
    # Haptic Feedback
    # -------------------------
    if haptic_feedback.lower() == 'true':
        ff_node = ExecuteProcess(
            cmd=['ros2', 'run', 'omni_common', 'ff.py'],
            output='screen'
        )
        nodes_to_launch.append(ff_node)
        print("[INFO] Haptic feedback enabled → Launching ff.py")
    else:
        print("[INFO] Haptic feedback disabled")
    
    return nodes_to_launch


def generate_launch_description():
    return LaunchDescription([
        # -------------------------
        # Launch Arguments
        # -------------------------
        DeclareLaunchArgument(
            'use_sim',
            default_value='true',
            description='Use simulation (true) or real robot (false)',
            choices=['true', 'false']
        ),
        
        DeclareLaunchArgument(
            'haptic_feedback',
            default_value='false',
            description='Enable haptic feedback (ff.py)',
            choices=['true', 'false']
        ),
        
        DeclareLaunchArgument(
            'teleoperation',
            default_value='false',
            description='Enable teleoperation mode',
            choices=['true', 'false']
        ),
        
        DeclareLaunchArgument(
            'teleop_mode',
            default_value='host',
            description='Teleoperation mode: router (zenoh daemon) or host (omni.launch.py)',
            choices=['router', 'host']
        ),
        
        # Set ROS domain ID
        SetEnvironmentVariable('ROS_DOMAIN_ID', '7'),
        
        # Launch setup function
        OpaqueFunction(function=launch_setup)
    ])
